from pathlib import Path
from zipfile import ZipFile

with ZipFile("Zip_example.zip", "w") as zip1:
    for path in Path("E:\Devops\Ayush_Vanparia\Python Standard Library").rglob("*.*"):
        zip1.write(path)


# with ZipFile("Zip_example") as zip2:
#     print(zip2.namelist())
